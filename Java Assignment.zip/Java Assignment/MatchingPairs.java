package assign;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
public class MatchingPairs 
{		
public static void main(String[] args) 
{
	int noOfNames;
	Scanner sc = new Scanner(System.in);
	sc.useDelimiter("\n");
	System.out.println("Program Starts");
	noOfNames = Integer.parseInt(sc.nextLine());
		
	String[] fullNames = new String[noOfNames];
	for(int i=0; i<fullNames.length; i++)
	{
		fullNames[i] = sc.next();
	}
	Set<String> aset = new HashSet<>();
	String fName,lName,fName1,lName1;
	String[] name = new String[2];
	String[] name1 = new String[2];
	for(int i=0; i<fullNames.length;i++)
	{
			name = fullNames[i].split(" ");
			fName = name[0];
			lName = name[1];
			for(int j=0; j<fullNames.length; j++)
			{
				if(i!=j)
				{
					name1 = fullNames[j].split(" ");
					fName1 = name1[0];
					lName1 = name1[1];
					if(fName.equals(fName1) && lName.equals(lName1) || fName.equals(lName1) && lName.equals(fName1))
					{
						aset.add(fName+" "+lName);
					}
					else
					{
						aset.add(fName1+" "+lName1);
					}
				}
			}

		}
		System.out.println(aset.size());
		Iterator<String> iter = aset.iterator();
		while(iter.hasNext()){
			System.out.println(iter.next());
		}
}
}

	


