import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel 
{
	public static void main(String args[]) {
	try {

		FileInputStream file = new FileInputStream(new File("C:\\Users\\lenovo\\eclipse-workspace\\ExcelOperation\\ExcelRead.xlsx"));
		XSSFWorkbook workbook = new XSSFWorkbook (file);
		XSSFSheet sheet = workbook.getSheetAt(0);
	   
	    Iterator <Row> rowIterator = sheet.iterator();
	    String[] names = new String[sheet.getLastRowNum()];
	    double[] marks = new double[sheet.getLastRowNum()];
	    
	    int n = 0;
	    int m = 0;
	   
	    Row row = rowIterator.next();
	    
	    while (rowIterator.hasNext()) {
	        row = rowIterator.next();
	        
	        Iterator <Cell> cellIterator = row.cellIterator();
	        while (cellIterator.hasNext()) {

	            Cell cell = cellIterator.next();
	            
	            switch (cell.getCellType()) {
	            
	                case NUMERIC:
	                    marks[n] = cell.getNumericCellValue();
	                    n++;
	                    break;
	                    
	                case STRING:
	                    names[m] = cell.getStringCellValue();
	                    m++;
	                    break;
	                default:
						break;
	            }
	        }
	    }
	    
	    file.close();
	    
	    XSSFSheet outputSheet = workbook.createSheet("Output");
	
	    row = outputSheet.createRow(0);

	    Cell cell;
	    
	    cell = row.createCell(0);
	    cell.setCellValue("Student Name");
	    cell  = row.createCell(1);
	    cell.setCellValue("Student Marks");
	    cell  = row.createCell(2);
	    cell.setCellValue("Percentage");
	 
	    double val;
	    int i = 1;
	    BigDecimal per = new BigDecimal(0.0);
	    Map < String, Object[] > data = new HashMap < String, Object[] > ();
	    
	 	for(int j=0; j<marks.length; j++) {
	 		
	 	    val = (marks[j] /1000)* 100;
	 	    per  = BigDecimal.valueOf(val).setScale(2,RoundingMode.HALF_UP);

	 	    if(per.doubleValue() >= 35.00) {
	 	    	String no = ""+i;
	 		    data.put(no, new Object[] {
	 		    			names[j],
	 		    			marks[j],
	 		    			per.doubleValue()
	 			    	});
	 		    i++;
	 	    }
	    }
	    
	    Set < String > keyset = data.keySet();
	    
	    int rownum = 1;
	    
	    for (String key: keyset) {
	        Row row2 = outputSheet.createRow(rownum++);
	        Object[] objArr = data.get(key);
	        int cellnum = 0;
	        for (Object obj: objArr) {
	            Cell cell1 = row2.createCell(cellnum++);
	            if (obj instanceof String)
	                cell1.setCellValue((String) obj);
	            else if (obj instanceof Double)
	                cell1.setCellValue((Double) obj);
	        }
	    }
	    //D:\\EclipseProg\\Apachepoi\\ExcelRead.xlsx
	    //D:\\new.xlsx
	    FileOutputStream out = new FileOutputStream(new File("C:\\Users\\lenovo\\eclipse-workspace\\ExcelOperation\\ExcelRead.xlsx"));
	    workbook.write(out);
	    out.close();
	    workbook.close();
	    System.out.println("Excel written successfully..");    
	
	} catch (FileNotFoundException e1) {
	    e1.printStackTrace();
	} catch (IOException e) {
	    e.printStackTrace();
	    }
  }
}



