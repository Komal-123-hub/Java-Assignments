
import java.util.Scanner;
public class MinimumJump {
    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        int i=0,k,z,jump=0;
        
        System.out.println("Enter the size of array : ");
        int size = s.nextInt();
        int[] arr = new int[size];
        System.out.println("Enter the elements of the array : ");
        for(int j=0; j<arr.length; j++){
            arr[j] = s.nextInt();
        }
        
        while(i <= arr.length-2){
            k=0;
            z=0;
            if(arr[i]==0||arr[i]==1){
                k=i+1;
                if(arr[k]==1){
                    i=i+2;
                    jump = jump+1;   
                }else if(arr[k]==0 ){
                    z = i+2;
                    if(z < arr.length-1){
                        if(arr[z]==0 ){
                            i=i+2;
                            jump=jump+1;     
                        }else{
                            jump=jump+1;
                            i=i+1;
                        }     
                    }else{
                        jump = jump+1;
                        break;
                    }
                }
            }      
        }
        System.out.println("Jump : "+jump);
    }   
}


