/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class BankTest {
    
    public static void main(String[] args){
        long bankAccountNumber;
        String accountHolderName;
        double loanAmount;
        int loanTenure;
        int cibilScore;
        String bankName;
        
        Scanner scan = new Scanner(System.in);
        System.out.print("Bank Account Number : ");
        bankAccountNumber = scan.nextLong();
        System.out.print("\nAccount Holder name : ");
        accountHolderName = scan.next();
        System.out.println("\nLoan Amount : ");
        loanAmount = scan.nextDouble();
        System.out.println("\nLoan Tenure : ");
        loanTenure = scan.nextInt();
        System.out.println("\nBank Name : ");
        bankName = scan.next();
        System.out.println("\nCIBIL Score : ");
        cibilScore = scan.nextInt();
        
        switch(bankName){
        
            case "SBI" :
                                SBI sbiBank = new SBI(bankAccountNumber,accountHolderName,cibilScore);
                                checkAndCalculate(sbiBank,loanAmount,SBI.INTREST_RATE, loanTenure, cibilScore);
                                break;
                             
            case "BOB" : 
                                BOB bobBank = new BOB(bankAccountNumber,accountHolderName,cibilScore);
                                checkAndCalculate(bobBank,loanAmount,BOB.INTREST_RATE, loanTenure, cibilScore);
                                break;
                            
                
            case "CitiBank" : 
                                Citibank citiBank = new Citibank(bankAccountNumber,accountHolderName,cibilScore);
                                checkAndCalculate(citiBank,loanAmount,Citibank.INTREST_RATE, loanTenure, cibilScore);
                                break;
                
            case "ICICI" :   
                                ICICI iciciBank = new ICICI(bankAccountNumber,accountHolderName,cibilScore);
                                checkAndCalculate(iciciBank,loanAmount,ICICI.INTREST_RATE, loanTenure, cibilScore);
                                break;
                                
            default :           System.err.println("Bank not Found");
                                break;
       }
        
    }
    private static void checkAndCalculate(Bank b,double loanAmount,double rateOfIntrest, int loanTenure, int cibilScore){
        
        System.out.println("\n"+b.toString());
        if(cibilScore >= 800){
            System.out.println("EMI : "+ b.calculateEMI(loanAmount, rateOfIntrest,loanTenure));
            System.out.println("InterestPayable:"+b.calculateIntrestPayble(loanAmount,loanTenure));
            System.out.println("Total Payable:"+b.calculateTotalPayable(loanAmount, loanTenure));
        }else{
            System.out.println("Account Holder not eligible for Loan");
        }
        
    }        
    
}


 
