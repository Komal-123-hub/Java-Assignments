import java.math.BigDecimal;
import java.math.RoundingMode;

public abstract class Bank {
    
    private long bankAccountNumber;
    private String accountHolderName;
    private int cibilScore;
    
    public Bank(long bankAccountNumber, String accountHolderName,int cibilScore){
        this.bankAccountNumber = bankAccountNumber;
        this.accountHolderName = accountHolderName;
        this.cibilScore =cibilScore;
           
    }
    /* --------------- Formulas --------------------*/
    // EMI = P*R*[(1+r)^n / ((1+r)^n)-1]
    // Intrest Payble = (EMI*noOfMonths)-loanAmount
    // Total Payble = loanAmount + IntrestPayble
    /*-----------------------------------------------*/
    protected BigDecimal calculateEMI(double loanAmount,double intrestRate ,int loanTenure){
        
        BigDecimal pAmt = BigDecimal.valueOf(loanAmount);
        BigDecimal roi  = BigDecimal.valueOf(intrestRate).divide(new BigDecimal("1200"),1000,RoundingMode.HALF_UP).setScale(8,RoundingMode.HALF_UP);        
        int noOfMonths = yearsToMonths(loanTenure);
        
        BigDecimal num = (BigDecimal.ONE.add(roi)).pow(noOfMonths).setScale(5,RoundingMode.HALF_UP); 

        BigDecimal deno = num.subtract(new BigDecimal("1")).setScale(5,RoundingMode.HALF_UP);  
       
        BigDecimal EMI = (pAmt.multiply(roi).setScale(5,RoundingMode.HALF_UP)
                             .multiply(num.divide(deno,1000,RoundingMode.HALF_UP).setScale(5,RoundingMode.HALF_UP)))
                             .setScale(2,RoundingMode.HALF_UP);
      
        return EMI;
    }
      
    protected abstract BigDecimal calculateIntrestPayble(double loanAmount, int loanTenure);
       
    protected abstract BigDecimal calculateTotalPayable(double loanAmount, int loanTenure);
    
    protected int yearsToMonths(int loanTenure){
        return loanTenure*12;
    }
    
    @Override
    public String toString(){
        return "Bank Account Number : "+bankAccountNumber+"\n"
                +"Account Holder Name : "+accountHolderName+"\n"
                +"CIBIL Score : "+cibilScore;
               
    } 
}

class BOB extends Bank{
    protected final static double INTREST_RATE =6.85;
    private final String BANK_NAME = "BOB";

    public BOB(long bankAccountNumber, String accountHolderName,int cibilScore){      
        super(bankAccountNumber, accountHolderName,cibilScore);
    }
    
    @Override
    protected BigDecimal calculateEMI(double loanAmount,double rateOfIntrest, int loanTenure){
        return super.calculateEMI(loanAmount, rateOfIntrest, loanTenure);    
    }
    
    @Override
    protected BigDecimal calculateIntrestPayble(double loanAmount, int loanTenure){
        BigDecimal EMI = calculateEMI(loanAmount, INTREST_RATE, loanTenure);
        int noOfMonths = loanTenure*12;
        BigDecimal intrestPayble = (EMI.multiply(BigDecimal.valueOf(noOfMonths))).subtract(BigDecimal.valueOf(loanAmount));
        return intrestPayble;
    }
    
    
    protected BigDecimal calculateTotalPayable(double loanAmount, int loanTenure){
        BigDecimal totalPayble = BigDecimal.valueOf(loanAmount).add(calculateIntrestPayble(loanAmount, loanTenure));
        return totalPayble;
    }
   
    @Override
        public String toString(){
                  return "Bank Name : "+BANK_NAME+"\n"
                          +super.toString();   
    } 
}

class Citibank extends Bank{
    protected final static double INTREST_RATE =6.75;
    private final String BANK_NAME = "Citibank";
    public Citibank(long bankAccountNumber, String accountHolderName,int cibilScore){      
        super(bankAccountNumber, accountHolderName,cibilScore);
    }
    
    @Override
    protected BigDecimal calculateEMI(double loanAmount,double rateOfIntrest, int loanTenure){
        return super.calculateEMI(loanAmount, rateOfIntrest, loanTenure);    
    }
    
    @Override
    protected BigDecimal calculateIntrestPayble(double loanAmount, int loanTenure){
        BigDecimal EMI = calculateEMI(loanAmount, INTREST_RATE, loanTenure);
        int noOfMonths = loanTenure*12;
        BigDecimal intrestPayble = (EMI.multiply(BigDecimal.valueOf(noOfMonths))).subtract(BigDecimal.valueOf(loanAmount));
        return intrestPayble;
    }
    
    @Override
    protected BigDecimal calculateTotalPayable(double loanAmount, int loanTenure){
        BigDecimal totalPayble = BigDecimal.valueOf(loanAmount).add(calculateIntrestPayble(loanAmount, loanTenure));
        return totalPayble;
    }
   
    @Override
        public String toString(){
                  return "Bank Name : "+BANK_NAME+"\n"
                          +super.toString();     
    }
}
   
class SBI extends Bank{
    protected final static double INTREST_RATE =6.70;
    private final String BANK_NAME = "SBI";
    public SBI(long bankAccountNumber, String accountHolderName,int cibilScore){      
        super(bankAccountNumber, accountHolderName,cibilScore);
    }
    
    @Override
    protected BigDecimal calculateEMI(double loanAmount,double rateOfIntrest, int loanTenure){
        return super.calculateEMI(loanAmount, rateOfIntrest, loanTenure);    
    }
    
    @Override
    protected BigDecimal calculateIntrestPayble(double loanAmount, int loanTenure){
        BigDecimal EMI = calculateEMI(loanAmount, INTREST_RATE, loanTenure);
        int noOfMonths = loanTenure*12;
        BigDecimal intrestPayble = (EMI.multiply(BigDecimal.valueOf(noOfMonths))).subtract(BigDecimal.valueOf(loanAmount));
        return intrestPayble;
    }
    
    @Override
    protected BigDecimal calculateTotalPayable(double loanAmount, int loanTenure){
        BigDecimal totalPayble = BigDecimal.valueOf(loanAmount).add(calculateIntrestPayble(loanAmount, loanTenure));
        return totalPayble;
    }
   
    @Override
        public String toString(){
                  return "Bank Name : "+BANK_NAME+"\n"
                          +super.toString();   
    } 
}


class ICICI extends Bank{
    protected final static double INTREST_RATE =6.90;
    private final String BANK_NAME = "ICICI";
    public ICICI(long bankAccountNumber, String accountHolderName,int cibilScore){      
        super(bankAccountNumber, accountHolderName,cibilScore);
    }
    
    @Override
    protected BigDecimal calculateEMI(double loanAmount,double rateOfIntrest, int loanTenure){
        return super.calculateEMI(loanAmount, rateOfIntrest, loanTenure);    
    }
    
    @Override
    protected BigDecimal calculateIntrestPayble(double loanAmount, int loanTenure){
        BigDecimal EMI = calculateEMI(loanAmount, INTREST_RATE, loanTenure);
        int noOfMonths = loanTenure*12;
        BigDecimal intrestPayble = (EMI.multiply(BigDecimal.valueOf(noOfMonths))).subtract(BigDecimal.valueOf(loanAmount));
        return intrestPayble;
    }
    
    @Override
    protected BigDecimal calculateTotalPayable(double loanAmount, int loanTenure){
        BigDecimal totalPayble = BigDecimal.valueOf(loanAmount).add(calculateIntrestPayble(loanAmount, loanTenure));
        return totalPayble;
    }
   
    @Override
        public String toString(){
                  return "Bank Name : "+BANK_NAME+"\n"
                          +super.toString();   
    } 
}

