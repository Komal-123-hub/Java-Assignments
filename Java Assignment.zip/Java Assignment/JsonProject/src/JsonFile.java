
import java.io.FileReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
  
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.*;
  

public class JsonFile {
    public static void main(String[] args) throws Exception 
    {   
        Object obj = new JSONParser().parse(new FileReader("JsonFile.json.txt"));
        
        
        Map<Object,Object> items = new HashMap<>();
        
        Iterator<Map.Entry<String,Object>> itr1 ; 
        JSONObject jo = (JSONObject) obj;
        JSONArray ja = (JSONArray) jo.get("labs");
        
		// iterating labs
        Iterator itr2 = ja.iterator();
            
        Map<String,Object> amap;                                     
        while (itr2.hasNext()) 
        {   
        	amap = (Map) itr2.next();
        	if(amap.get("time").equals("Today")) {
        		
        		itr1 = amap.entrySet().iterator();
                while (itr1.hasNext()) {
                    Map.Entry pair = itr1.next();
                    if(!pair.getKey().equals("time") ) {
                    	//items.put(pair.getKey(), pair.getValue());
                    	items.put(amap.get("name"), amap.get("location"));
                      //  System.out.println(pair.getKey() + " : " + pair.getValue());
                        
                    }
                }
        		
        	}
	    }
		Set<Map.Entry<Object, Object>> set = items.entrySet();
      // System.out.println(set.size());
		System.out.println(">>>>>>>>>>>>>>>Lab Array<<<<<<<<<<<<<<<<");
        for(Map.Entry<Object, Object> e : set) {
        	System.out.println(e.getKey()+" : "+e.getValue());
        }
        JSONArray jb = (JSONArray) jo.get("medications");
        Iterator itr3 = jb.iterator();
        Map<Object,Object> items1 = new HashMap<>();
        Iterator<Map.Entry<String,Object>> itr11 ;
        while(itr3.hasNext()) 
        {  
        	Map<String,Object> jsonArray = (Map)itr3.next();
        	Set<String> keySet = jsonArray.keySet();
        	
        	Iterator<String> iterator = keySet.iterator();
        	while(iterator.hasNext()) {
        		String key = iterator.next();
        		JSONArray jj =(JSONArray) jsonArray.get(key);	
        		
        		Iterator itr4 = jj.iterator();
            	Map<String,Object> amap1;
            	while (itr4.hasNext()) 
                {  
            		amap1 = (Map) itr4.next();
            		if(amap1.get("route").equals("PO")) {
            			itr11 = amap1.entrySet().iterator();
            			while (itr11.hasNext()) 
            	        {   
            	           Map.Entry pair = itr11.next();
            	           if(!pair.getKey().equals("route") ) {
            	                    	items1.put(amap1.get("name"), amap1.get("strength"));           
            	            }
            	         }		
            	     }
                 }
             }
        }
        Set<Map.Entry<Object, Object>> set1 = items1.entrySet();
        System.out.println("------------------------------------------");
        System.out.println(">>>>>>>>>>>>>>>>Medication Array<<<<<<<<<<<<<<<<<");
        for(Map.Entry<Object, Object> e : set1) {
        	System.out.println(e.getKey()+" : "+e.getValue());
        }
        		
    }

}